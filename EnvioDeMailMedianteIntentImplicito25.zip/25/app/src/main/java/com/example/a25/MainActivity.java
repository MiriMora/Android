package com.example.a25;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText etDireccion;
    EditText etTema;
    EditText etContenido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etDireccion=findViewById(R.id.etDireccion);
        etContenido=findViewById(R.id.eteContenido);
        etTema=findViewById(R.id.etTema);
    }

    public void enviar(View v){
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,new String[]{etDireccion.getText().toString()});
        intent.putExtra(Intent.EXTRA_SUBJECT,etTema.getText().toString());
        intent.putExtra(Intent.EXTRA_TEXT,etContenido.getText().toString());
        startActivity(intent);
    }
}