package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Persona>personas;
    RecyclerView rv1;
     TextView et1,et2;
     AdaptadorPersona ap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv1=findViewById(R.id.rv1);
        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        personas=new ArrayList<Persona>();
        personas.add(new Persona("Ana","678134117"));
        personas.add(new Persona("Raquel","653032178"));
        personas.add(new Persona("Laura","639187115"));
        personas.add(new Persona("Jaime","632187114"));

        LinearLayoutManager l = new LinearLayoutManager(this);
        rv1.setLayoutManager(l);
        ap = new AdaptadorPersona();
        rv1.setAdapter(ap);
    }
    //Implementar los botones : AGREGAR
    public void agregar(View v){
        Persona persona= new Persona(et1.getText().toString(),et2.getText().toString());
        personas.add(persona);
        et1.setText("");
        et2.setText("");
        ap.notifyDataSetChanged();
        rv1.scrollToPosition(personas.size());
    }
    //Implementamos metodo Mostrar(OnClickListener)

    public void mostrar(int pos){
        et1.setText(personas.get(pos).getNombre());
        et2.setText(personas.get(pos).getTelefono());
    }

    //Implementamos Boton Eliminar
    public void eliminar(View v){
        int pos = -1;
        for (int f= 0; f<personas.size();f++){
            if (personas.get(f).getNombre().equals(et1.getText().toString())){
                pos = f;
            }
            if (pos!= -1){
                et1.setText("");
                et2.setText("");
                ap.notifyDataSetChanged();
                Toast.makeText(this,"Se elimino a la persona: ",Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this,"No existe la persona: ",Toast.LENGTH_SHORT).show();
            }
        }

    }


    // IMPLEMENTANDO CLASE ADAPTADOR PERSONA: (Antes que Botones Agregar/eliminar)

    public class AdaptadorPersona extends RecyclerView.Adapter<AdaptadorPersona.AdapadorPersonaHolder>{

        @NonNull
        @Override
        public AdapadorPersonaHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdapadorPersonaHolder(getLayoutInflater().inflate(R.layout.itempersona,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull AdapadorPersonaHolder holder, int position) {
            holder.imprimir(position);

        }

        @Override
        public int getItemCount() {
            return personas.size();
        }

        class AdapadorPersonaHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
            TextView tv1;
            TextView tv2;

            public AdapadorPersonaHolder(View itemView) {
                super(itemView);
                tv1=itemView.findViewById(R.id.tvnombre);
                tv2=itemView.findViewById(R.id.tvtelefono);
                itemView.setOnClickListener(this);
            }
            public void imprimir(int position){
                tv1.setText("Nombre: " + personas.get(position).getNombre());
                tv2.setText("Telefono: " + personas.get(position).getTelefono());
            }

            @Override
            public void onClick(View view) {
                mostrar(getLayoutPosition());

            }
        }
    }


}