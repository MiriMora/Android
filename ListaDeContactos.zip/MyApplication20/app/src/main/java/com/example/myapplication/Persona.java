package com.example.myapplication;

public class Persona {
   private String nombre;
   private String telefono;

   public Persona(String nombre,String telefono){
       this.telefono= telefono;
       this.nombre=nombre;
   }

    public String getNombre() {
        return nombre;
    }
    public String getTelefono(){
       return telefono;
    }
}
