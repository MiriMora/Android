package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Actividad2 extends AppCompatActivity {
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad2);
        tv1=findViewById(R.id.tv1);
        Bundle datos=getIntent().getExtras();
        int valor1= datos.getInt("valor1");
        int valor2= datos.getInt("valor2");
        String op= datos.getString("operacion");


        switch (op){
            case "sumar":
                int suma = valor1 + valor2;
                tv1.setText(valor1+ "+" +valor2+ "=" +suma);
                break;
            case "restar":
                int resta = valor1 - valor2;
                tv1.setText(valor1+ "-" +valor2+ "=" +resta);
                break;
            case "multiplicar":
                int mult = valor1 * valor2;
                tv1.setText(valor1+ "*"+valor2+"="+mult);
                break;
            case "dividir":
                int div = valor1 / valor2;
                tv1.setText(valor1+"/"+valor2+"="+div);
                break;
        }
    }
    public void regresar (View v){
        finish();
    }
}