package com.example.juego;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageView [][] mat= new ImageView[4][4];
    private int [][]tablero={
            {1,1,2,2},
            {3,3,4,4},
            {5,5,6,6},
            {7,7,8,8}

    };
    private boolean activo = true;
    private int nropresion;
    private int primerox=-1;
    private int primeroy=-1;
    private Handler manejador=new Handler(Looper.myLooper());
    private boolean[][] destapado= new boolean[4][4];



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mat[0][0]=findViewById(R.id.imageView1);
        mat[0][1]=findViewById(R.id.imageView2);
        mat[0][2]=findViewById(R.id.imageView3);
        mat[0][3]=findViewById(R.id.imageView4);
        mat[1][0]=findViewById(R.id.imageView5);
        mat[1][1]=findViewById(R.id.imageView6);
        mat[1][2]=findViewById(R.id.imageView7);
        mat[1][3]=findViewById(R.id.imageView8);
        mat[2][0]=findViewById(R.id.imageView9);
        mat[2][1]=findViewById(R.id.imageView10);
        mat[2][2] =findViewById(R.id.imageView11);
        mat[2][3]=findViewById(R.id.imageView12);
        mat[3][0] =findViewById(R.id.imageView13);
        mat[3][1]=findViewById(R.id.imageView14);
        mat[3][2]=findViewById(R.id.imageView15);
        mat[3][3]=findViewById(R.id.imageView16);
        mezclarTablero();
    }
    private void mezclarTablero(){
        for (int f=0; f<1000; f++){
            int x1 = (int)(Math.random()*4);
            int y1=(int)(Math.random()*4);
            int x2= (int)(Math.random()*4);
            int y2=(int)(Math.random()*4);

            int aux = tablero[x1][y1];
            tablero[x1][y1] = tablero[x2][y2];
            tablero[x2][y2] = aux;
        }
    }
    public void presion(View v){
        if (activo)
            nropresion++;
            if (nropresion==2)
                if (v==mat[primerox][primeroy]){
                    nropresion--;
                    return;
                }
                verificarImagenpresionada(v);
                    if (nropresion==2){
                        congelar3seg();
                    }
                }
                private void congelar3seg() {
                    nropresion = 0;
                    activo = false;
                    primerox = -1;
                    primeroy = -1;
                    manejador.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            activo = true;
                            for (int f = 0; f < 4; f++)
                                for (int c = 0; c < 4; c++)
                                    if (destapado[f][c])
                                        destapar(mat[f][c], tablero[f][c]);
                                    else
                                        mat[f][c].setImageResource(R.drawable.oculto);
                        }
                    }, 3000);
                }



                private void verificarImagenpresionada(View v){
        for (int f = 0; f < 4; f++)
            for (int c = 0; c < 4; c++)
                if (mat[f][c]== v){
                    destapar(mat[f][c], tablero[f][c]);
                    if (nropresion == 1)
                        primerox = f;
                        primeroy = c;

                        return;
                }else {
                    if (tablero[f][c]==tablero[primerox][primeroy]){
                        destapado[f][c]= true;
                        destapado [primeroy][primerox] = true;
                        verificarSiGana();
                        nropresion = 0;
                        return;
                    }
                }
                }
                private void destapar(ImageView iv,int ima){
        switch (ima){
            case 1:
                iv.setImageResource(R.drawable.image1);
                break;
            case 2:
                iv.setImageResource(R.drawable.image2);
                break;
            case 3:
                iv.setImageResource(R.drawable.image3);
                break;
            case 4:
                iv.setImageResource(R.drawable.image4);
                break;
            case 5:
                iv.setImageResource(R.drawable.image5);
                break;
            case 6:
                iv.setImageResource(R.drawable.image6);
                break;
            case 7:
                iv.setImageResource(R.drawable.image7);
                break;
            case 8:
                iv.setImageResource(R.drawable.image8);
                break;
        }
                }

        private void verificarSiGana(){

        int destapados = 0;
        for (int f = 0; f < 4; f++)
            for (int c = 0 ; c < 4; c++)
                if (destapado[f][c]){
                    destapados ++;
                }
        if (destapados==16)
            Toast.makeText(this, "Ganoooo!!", Toast.LENGTH_SHORT).show();

                }




}

