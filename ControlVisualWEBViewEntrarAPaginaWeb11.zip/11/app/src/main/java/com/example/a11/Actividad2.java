package com.example.a11;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Actividad2 extends AppCompatActivity {
    WebView wv1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad2);
        //---- para que desaparezca la barra de arriba de nuestra app:
        getSupportActionBar().hide();
        //------
        wv1=findViewById(R.id.wv1);
        String direccion=getIntent().getExtras().getString("direccion");
        wv1.loadUrl(direccion);
        //Para que toda la informacion se quede en nuestra app
        wv1.setWebViewClient(new WebViewClient());
    }
    //Para que vuelva a la pag anterior: sobreescribimos (code->method->onKeyDown)


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==KeyEvent.KEYCODE_BACK && wv1.canGoBack()){
            wv1.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}